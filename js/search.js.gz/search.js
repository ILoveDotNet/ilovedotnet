﻿export function focusElement(id) {
    var element = document.getElementById(id);
    element.focus();
}